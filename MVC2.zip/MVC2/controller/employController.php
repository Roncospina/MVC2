<?php
require '../model/employModel.php';

class employController
{
    private $model;

    public function __construct()
    {
        $db = new PDO('mysql:host=localhost;dbname=company', 'root', '');
        $this->model = new employModel($db);
    }

    public function getEmploys()
    {
        return $this->model->getEmploys();
    }

    public function getEmploysById($id)
    {
        return $this->model->getEmploysById($id);
    }

    public function createEmploy($name, $last_name, $telephone, $email, $EPS, $ARL, $salary, $address)
    {
        return $this->model->createEmploy($name, $last_name, $telephone, $email, $EPS, $ARL, $salary, $address);
    }

    public function updateEmploy($id, $name, $last_name, $telephone, $email, $EPS, $ARL, $salary, $address)
    {
        return $this->model->updateEmploy($id, $name, $last_name, $telephone, $email, $EPS, $ARL, $salary, $address);
    }

    public function deleteEmploy($id)
    {
        return $this->model->deleteEmploy($id);
    }
}

<?php
require '../controller/employController.php';

$controller = new employController();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $last_name = $_POST['last_name'];
    $telephone = $_POST['telephone'];
    $email = $_POST['email'];
    $EPS = $_POST['EPS'];
    $ARL = $_POST['ARL'];
    $salary = $_POST['salary'];
    $address = $_POST['address'];

    $controller->updateEmploy($id, $name, $last_name, $telephone, $email, $EPS, $ARL, $salary, $address);
    header('Location: view.php');
    exit;
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $employ = $controller->getEmploysById($id);

    if (!$employ) {
        die('Employee not found');
    }
} else {
    die('Employee ID not specified');
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Edit Employee</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../CSS/style.css">

</head>

<body>
    <div class="container">
        <h1 class="text-center p-3">Edit Employee</h1>
        <form action="edit_process.php" method="POST">
            <input type="hidden" name="id" value="<?php echo $employ['id_emp']; ?>">
            <div class="form-group">
                <label>Name:</label>
                <input type="text" name="name" class="form-control" value="<?php echo $employ['name']; ?>" required>
            </div>
            <div class="form-group">
                <label>Last Name:</label>
                <input type="text" name="last_name" class="form-control" value="<?php echo $employ['last_name']; ?>" required>
            </div>
            <div class="form-group">
                <label>Telephone:</label>
                <input type="text" name="telephone" class="form-control" value="<?php echo $employ['telephone']; ?>">
            </div>
            <div class="form-group">
                <label>Email:</label>
                <input type="email" name="email" class="form-control" value="<?php echo $employ['email']; ?>">
            </div>
            <div class="form-group">
                <label>EPS:</label>
                <input type="text" name="EPS" class="form-control" value="<?php echo $employ['EPS']; ?>">
            </div>
            <div class="form-group">
                <label>ARL:</label>
                <input type="text" name="ARL" class="form-control" value="<?php echo $employ['ARL']; ?>">
            </div>
            <div class="form-group">
                <label>Salary:</label>
                <input type="number" name="salary" class="form-control" value="<?php echo $employ['salary']; ?>">
            </div>
            <div class="form-group">
                <label>Address:</label>
                <textarea name="address" class="form-control"><?php echo $employ['address']; ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
</body>

</html>
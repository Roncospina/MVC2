<?php
require_once '../controller/employController.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $last_name = $_POST['last_name'];
    $telephone = $_POST['telephone'];
    $email = $_POST['email'];
    $EPS = $_POST['EPS'];
    $ARL = $_POST['ARL'];
    $salary = $_POST['salary'];
    $address = $_POST['address'];

    $controller = new employController();

    $result = $controller->updateEmploy($id, $name, $last_name, $telephone, $email, $EPS, $ARL, $salary, $address);

    if ($result) {
        header('Location: index.php');
        exit();
    } else {
        echo 'Error al actualizar el empleado';
    }
} else {
    header('Location: index.php');
    exit();
}

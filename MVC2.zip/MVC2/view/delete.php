<?php
require '../controller/employController.php';

$controller = new employController();
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $employ = $controller->getEmploysById($id);

    if (!$employ) {
        die('Empleado no encontrado');
    }

    $controller->deleteEmploy($id);
    header('Location: index.php');
    exit;
} else {
    die('ID de empleado no especificado');
}

<!DOCTYPE html>
<html>

<head>
    <title>Crear Empleado</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../CSS/style.css">

</head>

<body>
    <div class="container">
        <h1 class="text-center p-3">Create Employee</h1>
        <form action="create_process.php" method="POST">
            <div class="form-group">
                <label>Name:</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Last Name:</label>
                <input type="text" name="last_name" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Telephone:</label>
                <input type="text" name="telephone" class="form-control">
            </div>
            <div class="form-group">
                <label>Email:</label>
                <input type="email" name="email" class="form-control">
            </div>
            <div class="form-group">
                <label>EPS:</label>
                <input type="text" name="EPS" class="form-control">
            </div>
            <div class="form-group">
                <label>ARL:</label>
                <input type="text" name="ARL" class="form-control">
            </div>
            <div class="form-group">
                <label>Salary:</label>
                <input type="number" name="salary" class="form-control">
            </div>
            <div class="form-group">
                <label>Address:</label>
                <textarea name="address" class="form-control"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Create</button>
        </form>
    </div>
</body>

</html>
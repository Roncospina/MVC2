<?php
class employView
{
    public function listEmploy($employ)
    {
        foreach ($employ as $employ) {
            echo "ID: " . $employ['id_emp'] . "<br>";
            echo "Name: " . $employ['name'] . "<br>";
            echo "Last Name: " . $employ['last_name'] . "<br>";
            echo "Telephone: " . $employ['telephone'] . "<br>";
            echo "Email: " . $employ['email'] . "<br>";
            echo "EPS: " . $employ['EPS'] . "<br>";
            echo "ARL: " . $employ['ARL'] . "<br>";
            echo "Salary: " . $employ['salary'] . "<br>";
            echo "Address: " . $employ['address'] . "<br>";
            echo "<br>";
        }
    }

    public function showMessage($message)
    {
        echo $message;
    }
}

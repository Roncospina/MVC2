<?php
require_once '../controller/employController.php';
require_once 'employView.php';

$controller = new employController();
$view = new employView();

// Obtener todos los empleados
$employ = $controller->getEmploys();
?>

<!DOCTYPE html>
<html>

<head>
    <h1 class="text-center p-3">CRUD MVC</h1>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../CSS/style.css">
    <script src=" https://kit.fontawesome.com/fc0f20eed5.js" crossorigin="anonymous">
    </script>
</head>

<body>
    <div class="containerr p-4">
        <a href="create.php" class="btn btn-success mb-4">Create Employee</a>
        <table class="table table-striped-columns table-dark">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Last Name</th>
                    <th>Telephone</th>
                    <th>Email</th>
                    <th>EPS</th>
                    <th>ARL</th>
                    <th>Salary</th>
                    <th>Address</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($employ as $employ) : ?>
                    <tr>
                        <td><?php echo $employ['id_emp']; ?></td>
                        <td><?php echo $employ['name']; ?></td>
                        <td><?php echo $employ['last_name']; ?></td>
                        <td><?php echo $employ['telephone']; ?></td>
                        <td><?php echo $employ['email']; ?></td>
                        <td><?php echo $employ['EPS']; ?></td>
                        <td><?php echo $employ['ARL']; ?></td>
                        <td><?php echo $employ['salary']; ?></td>
                        <td><?php echo $employ['address']; ?></td>
                        <td>
                            <a href="edit.php?id=<?php echo $employ['id_emp']; ?>" class="btn btn-sm btn-warning"><i class='fa-solid fa-marker'></i></a>
                            <a href="delete.php?id=<?php echo $employ['id_emp']; ?>" class="btn btn-sm btn-danger"><i class='fa-regular fa-trash-can'></i></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>

</html>
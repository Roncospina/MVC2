<?php
class employModel
{
    private $db;

    public function __construct($db)
    {
        $this->db = $db;
    }

    public function getEmploys()
    {
        $query = "SELECT * FROM employs";
        $result = $this->db->query($query);
        return $result->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getEmploysById($id)
    {
        $query = "SELECT * FROM employs WHERE id_emp = :id";
        $statement = $this->db->prepare($query);
        $statement->bindParam(':id', $id, PDO::PARAM_INT);
        $statement->execute();
        return $statement->fetch(PDO::FETCH_ASSOC);
    }

    public function createEmploy($name, $last_name, $telephone, $email, $EPS, $ARL, $salary, $address)
    {
        $query = "INSERT INTO employs (name, last_name, telephone, email, EPS, ARL, salary, address) 
                  VALUES (:name, :last_name, :telephone, :email, :EPS, :ARL, :salary, :address)";
        $statement = $this->db->prepare($query);
        $statement->bindParam(':name', $name, PDO::PARAM_STR);
        $statement->bindParam(':last_name', $last_name, PDO::PARAM_STR);
        $statement->bindParam(':telephone', $telephone, PDO::PARAM_STR);
        $statement->bindParam(':email', $email, PDO::PARAM_STR);
        $statement->bindParam(':EPS', $EPS, PDO::PARAM_STR);
        $statement->bindParam(':ARL', $ARL, PDO::PARAM_STR);
        $statement->bindParam(':salary', $salary, PDO::PARAM_INT);
        $statement->bindParam(':address', $address, PDO::PARAM_STR);
        $statement->execute();
        return $this->db->lastInsertId();
    }

    public function updateEmploy($id, $name, $last_name, $telephone, $email, $EPS, $ARL, $salary, $address)
    {
        $query = "UPDATE employs SET name = :name, last_name = :last_name, telephone = :telephone,
                  email = :email, EPS = :EPS, ARL = :ARL, salary = :salary, address = :address
                  WHERE id_emp = :id";
        $statement = $this->db->prepare($query);
        $statement->bindParam(':name', $name, PDO::PARAM_STR);
        $statement->bindParam(':last_name', $last_name, PDO::PARAM_STR);
        $statement->bindParam(':telephone', $telephone, PDO::PARAM_STR);
        $statement->bindParam(':email', $email, PDO::PARAM_STR);
        $statement->bindParam(':EPS', $EPS, PDO::PARAM_STR);
        $statement->bindParam(':ARL', $ARL, PDO::PARAM_STR);
        $statement->bindParam(':salary', $salary, PDO::PARAM_INT);
        $statement->bindParam(':address', $address, PDO::PARAM_STR);
        $statement->bindParam(':id', $id, PDO::PARAM_INT);
        return $statement->execute();
    }

    public function deleteEmploy($id)
    {
        $query = "DELETE FROM employs WHERE id_emp = :id";
        $statement = $this->db->prepare($query);
        $statement->bindParam(':id', $id, PDO::PARAM_INT);
        return $statement->execute();
    }
}
